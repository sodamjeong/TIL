# 기본 과제 틀 + 추가 기능

1. 각 Page Css
2. Form custom 
(생일 입력 추가, 정보 수정 페이지 비밀번호 help text 삭제_비밀번호 변경 버튼 별도 추가)
3. Favicon 추가
4. 각 Page title 적용
5. 이미지 추가, 삭제, 수정기능
6. Main 로딩 페이지 설정 (애니메이션)
7. Navbar 로고
8. Footer 추가
9. 좋아요 기능, 좋아요 수 표현
10. Onclick 기능 (Back, confirm)
11. 마이 페이지 추가
12. 회원가입 시, welcome 페이지 추가